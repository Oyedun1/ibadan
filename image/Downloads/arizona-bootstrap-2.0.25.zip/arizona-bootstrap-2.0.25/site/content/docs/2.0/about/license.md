---
layout: about
title: License
description: Information about Arizona Bootstrap's open source license.
group: about
---

{{< ourname >}} is released under the MIT license and is copyright {{< year >}} The Arizona Board of Regents on behalf of The University of Arizona.

{{< ourname >}} is based on Bootstrap version 4.

Bootstrap is released under the MIT license and is copyright {{< year >}} Twitter.

The full {{< ourname >}} license is located [in the project repository]({{< param repo >}}/blob/v{{< param current_version >}}/LICENSE) for more information.
