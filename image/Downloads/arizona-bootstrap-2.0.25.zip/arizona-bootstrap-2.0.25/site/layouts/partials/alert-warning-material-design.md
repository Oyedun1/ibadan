This feature in Arizona Bootstrap depends on Material Design Sharp icons which will still need to be added to your project if you would like to use them.

[Implement Material Icons]({{- (printf `docs/%s%s` $.Site.Params.docs_version `/icons/#material-icons-implementation`) | relURL -}})
